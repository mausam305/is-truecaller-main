# isTrueCaller - Fraud Call Detection System

![isTrueCaller Logo](src/isTrueCaller_frontend/public/logo2.svg)

## 🎯 About The Project

isTrueCaller is a community-driven fraud call detection system built on the Internet Computer platform. It helps users identify and report potentially fraudulent calls through a decentralized voting system, making phone communication safer for everyone.

## ✨ Features

- **Community-Based Voting System**: Users can vote on whether a call is fraudulent or legitimate
- **Real-Time Results**: Instant feedback on call status based on community votes
- **Call History**: View and track reported calls
- **Detailed Analytics**: See vote breakdowns and community consensus
- **Clean UI**: Modern, responsive interface for easy interaction

## 🚀 Live Demo

Visit our deployed application:
- **Frontend**: [https://zrmwl-iyaaa-aaaao-qj63q-cai.icp0.io/](https://zrmwl-iyaaa-aaaao-qj63q-cai.icp0.io/)
- **Backend (Candid Interface)**: [https://a4gq6-oaaaa-aaaab-qaa4q-cai.raw.icp0.io/?id=zwnq7-faaaa-aaaao-qj63a-cai](https://a4gq6-oaaaa-aaaab-qaa4q-cai.raw.icp0.io/?id=zwnq7-faaaa-aaaao-qj63a-cai)

## 🛠️ Technology Stack

- **Frontend**:
  - React.js
  - Vite
  - TailwindCSS
  - SCSS
  - Internet Computer (IC) SDK

- **Backend**:
  - Motoko (Internet Computer's native programming language)
  - Internet Computer Protocol (ICP)

## 📦 Project Structure

```
isTrueCaller/
├── src/
│   ├── isTrueCaller_backend/    # Motoko backend code
│   │   └── main.mo              # Main backend logic
│   └── isTrueCaller_frontend/   # React frontend code
│       ├── src/
│       │   ├── components/      # React components
│       │   ├── App.jsx          # Main app component
│       │   └── main.jsx         # Entry point
│       └── public/              # Static assets
├── dfx.json                     # Project configuration
└── package.json                 # Dependencies
```

## 🚦 Getting Started

### Prerequisites

- Node.js (v16 or higher)
- DFX (Internet Computer SDK)
- npm (v7 or higher)

### Installation

1. Clone the repository:
   ```bash
   git clone <repository-url>
   cd isTrueCaller
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the development environment:
   ```bash
   dfx start --clean --background
   npm run setup
   ```

4. Start the frontend development server:
   ```bash
   cd src/isTrueCaller_frontend
   npm start
   ```

## 🔍 Main Features Explained

### 1. Vote Submission
- Users can submit votes for specific call IDs
- Each vote can mark a call as either fraudulent or legitimate
- Real-time feedback on vote submission

### 2. Result Checking
- Check the current status of any reported call
- View detailed vote breakdowns
- See community consensus on call legitimacy

### 3. Call Management
- View all reported calls
- Check detailed statistics for each call
- Clear vote history for specific calls
- Track voting patterns and trends

## 🤝 Contributing

Contributions are welcome! Feel free to:
1. Fork the repository
2. Create your feature branch
3. Commit your changes
4. Push to the branch
5. Open a Pull Request


## 🌟 Acknowledgments

- Internet Computer Development Community
- React.js Community
- All contributors and users of the platform

---

🔗 **Important Links**
- [Report a Bug](https://github.com/yourusername/isTrueCaller/issues)
- [Request a Feature](https://github.com/yourusername/isTrueCaller/issues)
- [Get Support](https://github.com/yourusername/isTrueCaller/discussions)
